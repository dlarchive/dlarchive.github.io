<html>
<head>
<title>Lazada</title>

<style type="text/css">
	table { border-collapse: collapse; }
	
	td, th, table {border: thin solid black;padding:5px;}
	td.centered { text-align: center; }
	.numberical { width: 50px; }
	.iconimg { width: 6em; height: 6em; }
	.buttoncs { width: 6em; height: 2.5em; }
</style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

</head>
<body>

<script>

if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}

</script>

<script>
function goReturn(){
	window.location.href = "lazada.html";
}
</script>

<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

	//user var
	$vname = $_POST["name"];
	$vstreet = $_POST["street"];
	$vcity = $_POST["city"];
	$vpay = $_POST["paytype"];
	
	
			//FUNCTIONS TO GET
			function getQTY($product)
			{
				$qty = 0;
				
				if($product == "Mik-Mik"){
					$qty = $_POST["prodq1"];
				}
				else if($product == "Cheeese Ring"){
					$qty = $_POST["prodq2"];
				}
				else if($product == "Choc Nut"){
					$qty = $_POST["prodq3"];
				}
				else if($product == "Snacku"){
					$qty = $_POST["prodq4"];
				}
				else if($product == "Flat Tops"){
					$qty = $_POST["prodq5"];
				}
				else if($product == "Potchi"){
					$qty = $_POST["prodq6"];
				}
				else if($product == "White Rabbit"){
					$qty = $_POST["prodq7"];
				}
				else if($product == "Tomi"){
					$qty = $_POST["prodq8"];
				}
				else if($product == "Ri-Chee"){
					$qty = $_POST["prodq9"];
				}
				else {
					$qty = $_POST["prodq10"];
				}
				
				return $qty;
				
			}
			
			function getPrice($product)
			{
				$price = 0;
				
				if($product == "Mik-Mik"){
					$price = 3.00;
				}
				else if($product == "Cheeese Ring"){
					$price = 17.00;
				}
				else if($product == "Choc Nut"){
					$price = 2.00;
				}
				else if($product == "Snacku"){
					$price = 16.00;
				}
				else if($product == "Flat Tops"){
					$price = 5.00;
				}
				else if($product == "Potchi"){
					$price = 1.50;
				}
				else if($product == "White Rabbit"){
					$price = 2.00;
				}
				else if($product == "Tomi"){
					$price = 23.00;
				}
				else if($product == "Ri-Chee"){
					$price = 15.00;
				}
				else {
					$price = 1.00;
				}
				
				return $price;
				
			}
			
			function getRealID($product){
				
				$rID = "0";
				
				if($product == "Mik-Mik"){
					$rID = "1";
				}
				else if($product == "Cheeese Ring"){
					$rID = "2";
				}
				else if($product == "Choc Nut"){
					$rID = "3";
				}
				else if($product == "Snacku"){
					$rID = "4";
				}
				else if($product == "Flat Tops"){
					$rID = "5";
				}
				else if($product == "Potchi"){
					$rID = "6";
				}
				else if($product == "White Rabbit"){
					$rID = "7";
				}
				else if($product == "Tomi"){
					$rID = "8";
				}
				else if($product == "Ri-Chee"){
					$rID = "9";
				}
				else {
					$rID = "10";
				}
				
				return $rID;
				
			}
			
			function getSubTotal(){
				
				$subtotal = 0;
				
				foreach($_POST['prodselect'] as $selected){
					
					//variable needed
					$qty = getQTY($selected);
					$price = getPrice($selected);
					
					//compute
					$subtotal += ($price * $qty);
					
				}
				
				$subtotal = number_format($subtotal, 2);
				return $subtotal;
				
			}
			
			function getVat(){
				$subtotal = getSubTotal();
				
				$percentage = 12.00;
				$vat = ($percentage / 100.00) * $subtotal;
				$vat = number_format($vat, 2);
				
				return $vat;

			}
			
			function getTotal(){
				$subtotal = getSubTotal();
				$vat = getVat();
				
				$comTotal = $subtotal + $vat;
				$comTotal = number_format($comTotal, 2);
				
				return $comTotal;

			}
	
	
}
else{
	
	//go back home if no form action
	header("Location: lazada.html", true, 301);
	exit();
	
}
?>

<div align="center">
<h1>Sari-Sari Store</h1>

<form id="sari-sari-form" action="shopee.php" onsubmit="return validateForm();" method="post">
<!-- user details -->
<table>

	<tr>
		<td> Buyer's Name: </td>
		<td> <?php if ($_SERVER["REQUEST_METHOD"] == "POST") { print($vname); } ?> </td>
	</tr>
	<tr>
		<td> Street Address: </td>
		<td> <?php if ($_SERVER["REQUEST_METHOD"] == "POST") { print($vstreet); } ?> </td>
	</tr>
	<tr>
		<td> City, State, Zip: </td>
		<td> <?php if ($_SERVER["REQUEST_METHOD"] == "POST") { print($vcity); } ?> </td>
	</tr>
	<tr>
		<td> Payment Method: </td>
		<td> <?php if ($_SERVER["REQUEST_METHOD"] == "POST") { print($vpay); } ?>  </td>
	</tr>
	
</table>

<br>

<!-- user item selection -->
<table id="productList">
	<!-- First, the column headings -->
	<input type="hidden" name="spam" id="spam"/>
	<tr>
	
		<th> ID </th>
		<th> Image </th>
		<th> Product </th>
		<th> Price </th>
		<th> Quantity </th>
	</tr>
	<!-- Now, the table data entries -->
	<?php 
		if ($_SERVER["REQUEST_METHOD"] == "POST"){ 
			
			function startTableMaking(){
				
				foreach($_POST['prodselect'] as $selected){
					
					//variable needed
					$qty = getQTY($selected);
					$price = getPrice($selected);
					$rID = getRealID($selected);
					
					//format
					$price = number_format($price, 2);
					
					echo("
							<tr>
							<td class=\"centered\"> $rID </td>
							<td> <img class=\"iconimg\" src=\"image/prod$rID.jpg\"> </td>
							<td> $selected </td>
							<td> &#8369;$price </td>
							<td class=\"centered\">$qty</td>
							</tr>
						");
					
				} 
				
			}
			
			startTableMaking();
		} 
	
	
	?>
	
	
	
</table>

<br>

<table>

	<tr>
		<td> Subtotal: </td>
		<td>&#8369;
		<?php 
		if ($_SERVER["REQUEST_METHOD"] == "POST") { 
			
			$outputSubTotal = getSubTotal();		
			echo "$outputSubTotal";
		} 
		?>
		</td>
	</tr>
	<tr>
		<td> 12% VAT: </td>
		<td>&#8369;
		<?php 
		if ($_SERVER["REQUEST_METHOD"] == "POST") { 
			
			$outputVat = getVat();		
			echo "$outputVat";
		} 
		?>
		</td>
	</tr>
	<tr>
		<td> Total: </td>
		<td> &#8369;
		<?php 
		if ($_SERVER["REQUEST_METHOD"] == "POST") { 
			
			$outputTotal = getTotal();		
			echo "$outputTotal";
		} 
		?>
		</td>
	</tr>

</table>

<br>

<input class="buttoncs" type="button" onclick="goReturn();" value="Back">

</form>
</div>



</body>
</html>